package com.webservices;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SoapWebapplicationClientApplication {

	public static void main(String[] args) {
		SpringApplication.run(SoapWebapplicationClientApplication.class, args);
	}

}
