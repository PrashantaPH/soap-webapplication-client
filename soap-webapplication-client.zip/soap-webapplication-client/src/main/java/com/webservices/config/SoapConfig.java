package com.webservices.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;

import com.webservices.service.SoapClientService;

@Configuration
public class SoapConfig {

	@Bean
	public Jaxb2Marshaller jaxb2Marshaller() {
		Jaxb2Marshaller jaxb2Marshaller = new Jaxb2Marshaller();
		jaxb2Marshaller.setContextPath("com.seec.insurance.life.illustrationinquiry.ws");
		return jaxb2Marshaller;
	}
	
	@Bean
	public SoapClientService soapClientService(Jaxb2Marshaller jaxb2Marshaller) {
		SoapClientService soapClientService = new SoapClientService();
		
		soapClientService.setDefaultUri("http://localhost:8080/SJPBCSWebservice/services/IllustrationInquiryWS");
		soapClientService.setMarshaller(jaxb2Marshaller);
		soapClientService.setUnmarshaller(jaxb2Marshaller);
		
		return soapClientService;
	}
}
