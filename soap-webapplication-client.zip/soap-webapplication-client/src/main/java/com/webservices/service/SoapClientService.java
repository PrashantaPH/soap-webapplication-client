package com.webservices.service;

import org.springframework.stereotype.Service;
import org.springframework.ws.client.core.WebServiceTemplate;
import org.springframework.ws.client.core.support.WebServiceGatewaySupport;

import com.seec.insurance.life.illustrationinquiry.ws.ProcessIllustrationInquiry;
import com.seec.insurance.life.illustrationinquiry.ws.ProcessIllustrationInquiryResponse;

@Service
public class SoapClientService extends WebServiceGatewaySupport {

	public ProcessIllustrationInquiryResponse inquiryResponse(String str) {
		ProcessIllustrationInquiry illustrationInquiry = new ProcessIllustrationInquiry();
		illustrationInquiry.setTxlifeRequest(str);
		
		WebServiceTemplate serviceTemplate = getWebServiceTemplate();
		serviceTemplate.setMarshaller(getMarshaller());
		serviceTemplate.setUnmarshaller(getUnmarshaller());
		
		
		return (ProcessIllustrationInquiryResponse) serviceTemplate.marshalSendAndReceive(
				"https://platebsillusbs-211.sjp.co.uk/SJPBCSWebservice/services/IllustrationInquiryWS", illustrationInquiry);
		
	}
}
